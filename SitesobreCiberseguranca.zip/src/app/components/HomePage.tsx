import { Shield, Bell, BookOpen, FileText, TrendingUp, Users, Lock, AlertTriangle, ChevronRight, LogOut, Home, Settings, Award, Target, Search, MessageSquare } from 'lucide-react';
import { Link } from 'react-router';
import { useState } from 'react';
import logoImg from '../../imports/Logo_Olho_Digital.png';

interface HomePageProps {
  user: { name: string; email: string };
  onLogout: () => void;
}

export function HomePage({ user, onLogout }: HomePageProps) {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const quickStats = [
    { label: 'Artigos Lidos', value: '12', icon: BookOpen, color: 'blue' },
    { label: 'Conquistas', value: '5', icon: Award, color: 'purple' },
    { label: 'Dias Ativos', value: '7', icon: TrendingUp, color: 'green' },
  ];

  const recentArticles = [
    {
      title: 'Como proteger sua senha',
      category: 'Segurança Básica',
      readTime: '5 min',
      color: 'blue'
    },
    {
      title: 'Reconhecendo ataques de Phishing',
      category: 'Ameaças',
      readTime: '8 min',
      color: 'red'
    },
    {
      title: 'LGPD: O que você precisa saber',
      category: 'Legislação',
      readTime: '10 min',
      color: 'purple'
    }
  ];

  const threats = [
    {
      title: 'Novo ataque de Ransomware detectado',
      severity: 'alta',
      time: 'Há 2 horas'
    },
    {
      title: 'Vulnerabilidade em navegadores',
      severity: 'média',
      time: 'Há 5 horas'
    },
    {
      title: 'Campanha de phishing ativa',
      severity: 'alta',
      time: 'Há 1 dia'
    }
  ];

  const learningPaths = [
    {
      title: 'Fundamentos de Cibersegurança',
      progress: 60,
      icon: Shield,
      lessons: 8,
      completed: 5
    },
    {
      title: 'Proteção de Dados Pessoais',
      progress: 30,
      icon: Lock,
      lessons: 6,
      completed: 2
    },
    {
      title: 'Identificação de Ameaças',
      progress: 45,
      icon: AlertTriangle,
      lessons: 10,
      completed: 4
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center gap-8">
              <Link to="/home" className="flex items-center gap-3">
                <img src={logoImg} alt="Olho Digital" className="h-10 w-auto" />
                <h1 className="text-xl text-blue-900">Olho Digital</h1>
              </Link>
              <nav className="hidden md:flex items-center gap-6">
                <Link to="/home" className="flex items-center gap-2 text-blue-600">
                  <Home className="w-4 h-4" />
                  <span>Início</span>
                </Link>
                <Link to="/aprender" className="text-slate-600 hover:text-blue-600 transition-colors">Aprender</Link>
                <Link to="/noticias" className="text-slate-600 hover:text-blue-600 transition-colors">Notícias</Link>
                <Link to="/comunidade" className="text-slate-600 hover:text-blue-600 transition-colors">Comunidade</Link>
              </nav>
            </div>

            <div className="flex items-center gap-4">
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar..."
                  className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-64"
                />
              </div>

              <button className="relative p-2 text-slate-600 hover:text-blue-600 transition-colors">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>

              <div className="relative">
                <button
                  onClick={() => setShowProfileMenu(!showProfileMenu)}
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center text-white">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="hidden md:block text-left">
                    <p className="text-sm text-slate-900">{user.name}</p>
                    <p className="text-xs text-slate-500">{user.email}</p>
                  </div>
                </button>

                {showProfileMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-slate-200 py-2 z-10">
                    <button className="w-full px-4 py-2 text-left text-slate-700 hover:bg-slate-100 flex items-center gap-2">
                      <Settings className="w-4 h-4" />
                      <span>Configurações</span>
                    </button>
                    <button
                      onClick={onLogout}
                      className="w-full px-4 py-2 text-left text-red-600 hover:bg-red-50 flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sair</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl text-slate-900 mb-2">
            Olá, {user.name.split(' ')[0]}! 👋
          </h2>
          <p className="text-slate-600 mb-4">Continue aprendendo sobre cibersegurança e proteja-se no mundo digital</p>

          {/* Alerta de Autenticação */}
          <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded-lg flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div>
              <h4 className="text-yellow-900 mb-1">Necessário Autenticação de Dois Fatores</h4>
              <p className="text-yellow-800 text-sm">
                Proteja sua conta ativando a autenticação de dois fatores para maior segurança.
              </p>
              <button className="mt-2 text-yellow-700 hover:text-yellow-900 text-sm underline">
                Ativar agora
              </button>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {quickStats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="bg-white rounded-xl p-6 border border-slate-200 hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between mb-4">
                  <div className={`bg-${stat.color}-100 p-3 rounded-lg`}>
                    <Icon className={`w-6 h-6 text-${stat.color}-600`} />
                  </div>
                  <span className="text-3xl text-slate-900">{stat.value}</span>
                </div>
                <p className="text-slate-600">{stat.label}</p>
              </div>
            );
          })}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8">
            {/* Learning Paths */}
            <section>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl text-slate-900">Seus Cursos</h3>
                <a href="#" className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1">
                  Ver todos
                  <ChevronRight className="w-4 h-4" />
                </a>
              </div>
              <div className="space-y-4">
                {learningPaths.map((path, index) => {
                  const Icon = path.icon;
                  return (
                    <div key={index} className="bg-white rounded-xl p-6 border border-slate-200 hover:shadow-lg transition-shadow">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-start gap-4">
                          <div className="bg-blue-100 p-3 rounded-lg">
                            <Icon className="w-6 h-6 text-blue-600" />
                          </div>
                          <div>
                            <h4 className="text-slate-900 mb-1">{path.title}</h4>
                            <p className="text-sm text-slate-600">
                              {path.completed} de {path.lessons} aulas concluídas
                            </p>
                          </div>
                        </div>
                        <span className="text-blue-600">{path.progress}%</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${path.progress}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Recent Articles */}
            <section>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl text-slate-900">Artigos Recomendados</h3>
                <a href="#" className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1">
                  Ver todos
                  <ChevronRight className="w-4 h-4" />
                </a>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                {recentArticles.map((article, index) => (
                  <div key={index} className="bg-white rounded-xl p-6 border border-slate-200 hover:shadow-lg transition-shadow cursor-pointer group">
                    <div className={`inline-block bg-${article.color}-100 text-${article.color}-700 px-3 py-1 rounded-full text-xs mb-3`}>
                      {article.category}
                    </div>
                    <h4 className="text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {article.title}
                    </h4>
                    <div className="flex items-center gap-2 text-sm text-slate-500">
                      <FileText className="w-4 h-4" />
                      <span>{article.readTime} de leitura</span>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Right Column - Alerts */}
          <div className="lg:col-span-1">
            <section className="sticky top-4">
              <h3 className="text-2xl text-slate-900 mb-6">Alertas de Segurança</h3>
              <div className="space-y-4">
                {threats.map((threat, index) => (
                  <div key={index} className="bg-white rounded-xl p-5 border border-slate-200 hover:shadow-lg transition-shadow">
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-lg ${
                        threat.severity === 'alta' ? 'bg-red-100' : 'bg-orange-100'
                      }`}>
                        <AlertTriangle className={`w-5 h-5 ${
                          threat.severity === 'alta' ? 'text-red-600' : 'text-orange-600'
                        }`} />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-slate-900 mb-1 text-sm">{threat.title}</h4>
                        <div className="flex items-center justify-between">
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            threat.severity === 'alta'
                              ? 'bg-red-100 text-red-700'
                              : 'bg-orange-100 text-orange-700'
                          }`}>
                            {threat.severity === 'alta' ? 'Alta' : 'Média'}
                          </span>
                          <span className="text-xs text-slate-500">{threat.time}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Community Stats */}
              <div className="bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl p-6 text-white mt-6">
                <div className="flex items-center gap-2 mb-4">
                  <Users className="w-5 h-5" />
                  <h4>Comunidade</h4>
                </div>
                <div className="space-y-3">
                  <div>
                    <div className="text-3xl mb-1">12.5k</div>
                    <div className="text-blue-100 text-sm">Membros ativos</div>
                  </div>
                  <div className="border-t border-blue-400 pt-3">
                    <div className="text-2xl mb-1">234</div>
                    <div className="text-blue-100 text-sm">Discussões esta semana</div>
                  </div>
                </div>
                <button className="w-full bg-white text-blue-600 py-2 rounded-lg mt-4 hover:bg-blue-50 transition-colors">
                  Participar
                </button>
              </div>
            </section>
          </div>
        </div>
      </main>

      {/* Botão Assistente Flutuante */}
      <button className="fixed bottom-6 right-6 bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 transition-all hover:scale-110 z-50 flex items-center gap-2">
        <MessageSquare className="w-6 h-6" />
        <span className="hidden md:inline">Assistente Virtual</span>
      </button>
    </div>
  );
}
