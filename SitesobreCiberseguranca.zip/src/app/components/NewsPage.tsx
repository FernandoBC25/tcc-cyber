import { Shield, Bell, Newspaper, TrendingUp, User, Building2, AlertCircle, Calendar, LogOut, Home, Settings, Search, ExternalLink } from 'lucide-react';
import { Link } from 'react-router';
import { useState } from 'react';
import logoImg from '../../imports/Logo_Olho_Digital.png';

interface NewsPageProps {
  user: { name: string; email: string };
  onLogout: () => void;
}

export function NewsPage({ user, onLogout }: NewsPageProps) {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'todas' | 'famosos' | 'cotidiano'>('todas');

  const famousNews = [
    {
      id: 1,
      title: 'NASA sofre ataque cibernético e dados de missões são expostos',
      date: '15 de Maio, 2026',
      category: 'Empresas',
      image: 'nasa',
      content: 'A NASA confirmou que hackers conseguiram acessar sistemas internos por meio de uma vulnerabilidade em software de terceiros. Dados de projetos de exploração espacial foram comprometidos. O ataque demonstra que até mesmo as organizações mais preparadas do mundo estão vulneráveis a ataques cibernéticos sofisticados.',
      impact: 'Alto',
      lesson: 'Mesmo organizações com bilhões em segurança podem ser alvos. A cadeia de fornecedores é um ponto crítico.'
    },
    {
      id: 2,
      title: 'Banco Central do Brasil identifica tentativa de invasão massiva',
      date: '12 de Maio, 2026',
      category: 'Instituições',
      image: 'bank',
      content: 'O Banco Central brasileiro bloqueou uma tentativa de ataque DDoS que visava derrubar sistemas do PIX. O ataque, que durou 6 horas, foi mitigado pelas equipes de segurança. Especialistas afirmam que até mesmo instituições financeiras com as mais avançadas proteções continuam sendo alvos constantes.',
      impact: 'Crítico',
      lesson: 'Infraestruturas críticas são alvos permanentes e precisam de monitoramento 24/7.'
    },
    {
      id: 3,
      title: 'Microsoft confirma vazamento de código-fonte após ataque',
      date: '8 de Maio, 2026',
      category: 'Empresas',
      image: 'microsoft',
      content: 'A gigante de tecnologia Microsoft admitiu que hackers conseguiram acessar repositórios internos de código através de credenciais comprometidas de um funcionário. O caso reforça que mesmo as empresas mais preparadas tecnologicamente enfrentam ataques bem-sucedidos quando o fator humano está envolvido.',
      impact: 'Alto',
      lesson: 'O elo mais fraco em segurança geralmente são as pessoas, não a tecnologia.'
    },
    {
      id: 4,
      title: 'Hospitais Rede D\'Or paralisados por ransomware',
      date: '5 de Maio, 2026',
      category: 'Saúde',
      image: 'hospital',
      content: 'Uma das maiores redes hospitalares do Brasil teve seus sistemas criptografados por ransomware. Cirurgias foram adiadas e atendimentos comprometidos. Os hackers exigiram R$ 50 milhões em criptomoedas. O ataque mostra que até organizações de saúde bem estruturadas são vulneráveis a ataques que podem colocar vidas em risco.',
      impact: 'Crítico',
      lesson: 'Backups regulares e sistemas redundantes são essenciais para operações críticas.'
    },
    {
      id: 5,
      title: 'Google Cloud sofre falha de segurança e expõe dados de clientes',
      date: '1 de Maio, 2026',
      category: 'Empresas',
      image: 'google',
      content: 'Uma falha de configuração no Google Cloud Platform expôs dados de milhares de empresas clientes por 12 horas. O incidente demonstra que mesmo os maiores provedores de nuvem, com equipes especializadas e investimentos massivos em segurança, podem cometer erros que comprometem a segurança dos dados.',
      impact: 'Alto',
      lesson: 'Configurações incorretas são uma das principais causas de vazamentos, mesmo em grandes empresas.'
    }
  ];

  const dailyNews = [
    {
      id: 6,
      title: 'Aposentada de São Paulo perde R$ 80 mil em golpe do falso funcionário do banco',
      date: '14 de Maio, 2026',
      category: 'Cotidiano',
      image: 'user',
      content: 'Maria, de 68 anos, recebeu uma ligação de alguém se passando por funcionário do banco alertando sobre "transações suspeitas". Pressionada, ela forneceu dados da conta e códigos de segurança. Todo o dinheiro de sua aposentadoria foi roubado. O caso reforça que golpes simples continuam fazendo vítimas diariamente.',
      impact: 'Médio',
      lesson: 'Bancos nunca pedem senhas ou códigos por telefone. Sempre desligue e ligue você mesmo para o banco.'
    },
    {
      id: 7,
      title: 'Estudante tem Instagram hackeado e perde perfil com 50 mil seguidores',
      date: '13 de Maio, 2026',
      category: 'Cotidiano',
      image: 'user',
      content: 'Pedro, 22 anos, clicou em um link prometendo "verificação grátis" para seu perfil. Após inserir suas credenciais em uma página falsa, perdeu acesso à conta. Os hackers mudaram email e senha de recuperação. Casos como esse são extremamente comuns e afetam milhares de brasileiros mensalmente.',
      impact: 'Baixo',
      lesson: 'Use autenticação de dois fatores e nunca clique em links suspeitos, mesmo que pareçam oficiais.'
    },
    {
      id: 8,
      title: 'Mãe transfere R$ 5 mil para golpista se passando pelo filho',
      date: '10 de Maio, 2026',
      category: 'Cotidiano',
      image: 'user',
      content: 'Ana recebeu mensagens no WhatsApp de um número desconhecido dizendo ser seu filho, alegando que estava com o celular quebrado e precisava de dinheiro urgentemente. Desesperada, ela fez a transferência. Somente depois descobriu que era golpe. Esse tipo de fraude cresceu 200% no último ano.',
      impact: 'Médio',
      lesson: 'Sempre confirme por ligação de voz antes de fazer transferências, mesmo que pareça urgente.'
    },
    {
      id: 9,
      title: 'Professora cai em golpe de boleto falso e perde mensalidade do aluguel',
      date: '7 de Maio, 2026',
      category: 'Cotidiano',
      image: 'user',
      content: 'Carla recebeu um boleto por email que parecia ser do seu condomínio. Após pagar, descobriu que era falso - os golpistas haviam invadido o email do condomínio e enviado boletos adulterados para todos os moradores. Dezenas de pessoas foram vítimas do mesmo golpe.',
      impact: 'Médio',
      lesson: 'Sempre confira os dados do beneficiário no boleto antes de pagar, mesmo que pareça legítimo.'
    },
    {
      id: 10,
      title: 'Jovem tem WhatsApp clonado e amigos são extorquidos',
      date: '3 de Maio, 2026',
      category: 'Cotidiano',
      image: 'user',
      content: 'Lucas teve seu WhatsApp clonado após cair em um golpe que pedia o código de verificação. Os criminosos usaram sua conta para pedir dinheiro emprestado a todos os contatos. Mais de R$ 15 mil foram roubados de amigos e familiares antes que ele conseguisse recuperar a conta.',
      impact: 'Médio',
      lesson: 'Nunca compartilhe o código de verificação do WhatsApp com ninguém, nem mesmo "suporte técnico".'
    }
  ];

  const allNews = [...famousNews, ...dailyNews];

  const filteredNews = selectedCategory === 'todas'
    ? allNews
    : selectedCategory === 'famosos'
    ? famousNews
    : dailyNews;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center gap-8">
              <Link to="/home" className="flex items-center gap-3">
                <img src={logoImg} alt="Olho Digital" className="h-10 w-auto mix-blend-multiply" />
                <h1 className="text-xl text-blue-900">Olho Digital</h1>
              </Link>
              <nav className="hidden md:flex items-center gap-6">
                <Link to="/home" className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors">
                  <Home className="w-4 h-4" />
                  <span>Início</span>
                </Link>
                <Link to="/aprender" className="text-slate-600 hover:text-blue-600 transition-colors">Aprender</Link>
                <Link to="/noticias" className="text-blue-600">Notícias</Link>
                <Link to="/comunidade" className="text-slate-600 hover:text-blue-600 transition-colors">Comunidade</Link>
              </nav>
            </div>

            <div className="flex items-center gap-4">
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar notícias..."
                  className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-64"
                />
              </div>

              <button className="relative p-2 text-slate-600 hover:text-blue-600 transition-colors">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>

              <div className="relative">
                <button
                  onClick={() => setShowProfileMenu(!showProfileMenu)}
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center text-white">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                </button>

                {showProfileMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-slate-200 py-2 z-10">
                    <button className="w-full px-4 py-2 text-left text-slate-700 hover:bg-slate-100 flex items-center gap-2">
                      <Settings className="w-4 h-4" />
                      <span>Configurações</span>
                    </button>
                    <button
                      onClick={onLogout}
                      className="w-full px-4 py-2 text-left text-red-600 hover:bg-red-50 flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sair</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Newspaper className="w-8 h-8 text-blue-600" />
            <h2 className="text-3xl text-slate-900">Notícias de Cibersegurança</h2>
          </div>
          <p className="text-slate-600 mb-6">
            Casos reais de ataques cibernéticos - desde grandes corporações até pessoas comuns
          </p>

          {/* Filtros */}
          <div className="flex gap-3 mb-6">
            <button
              onClick={() => setSelectedCategory('todas')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                selectedCategory === 'todas'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-700 border border-slate-300 hover:border-blue-400'
              }`}
            >
              Todas
            </button>
            <button
              onClick={() => setSelectedCategory('famosos')}
              className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-2 ${
                selectedCategory === 'famosos'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-700 border border-slate-300 hover:border-blue-400'
              }`}
            >
              <Building2 className="w-4 h-4" />
              Casos Famosos
            </button>
            <button
              onClick={() => setSelectedCategory('cotidiano')}
              className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-2 ${
                selectedCategory === 'cotidiano'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-slate-700 border border-slate-300 hover:border-blue-400'
              }`}
            >
              <User className="w-4 h-4" />
              Cotidiano
            </button>
          </div>

          {/* Destaque */}
          {selectedCategory === 'todas' && (
            <div className="bg-gradient-to-br from-red-500 to-red-700 rounded-2xl p-8 text-white mb-8">
              <div className="flex items-start gap-4">
                <AlertCircle className="w-8 h-8 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-2xl mb-3">Importante: Ninguém está 100% seguro</h3>
                  <p className="text-red-100 leading-relaxed mb-4">
                    Até mesmo as empresas mais preparadas do mundo, com bilhões investidos em segurança e equipes especializadas, sofrem ataques cibernéticos bem-sucedidos. NASA, Microsoft, Google, bancos - todos já foram vítimas.
                  </p>
                  <p className="text-red-100 leading-relaxed">
                    Se até eles são vulneráveis, imagine o quanto você precisa estar atento. A diferença está na preparação: empresas grandes se recuperam rapidamente porque têm planos de contingência. Você também precisa estar preparado.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Grid de Notícias */}
        <div className="space-y-6">
          {filteredNews.map((news) => (
            <article key={news.id} className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition-shadow">
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    {news.category === 'Cotidiano' ? (
                      <div className="bg-blue-100 p-3 rounded-lg">
                        <User className="w-6 h-6 text-blue-600" />
                      </div>
                    ) : (
                      <div className="bg-purple-100 p-3 rounded-lg">
                        <Building2 className="w-6 h-6 text-purple-600" />
                      </div>
                    )}
                    <div>
                      <span className={`text-xs px-3 py-1 rounded-full ${
                        news.category === 'Cotidiano'
                          ? 'bg-blue-100 text-blue-700'
                          : 'bg-purple-100 text-purple-700'
                      }`}>
                        {news.category}
                      </span>
                      <div className="flex items-center gap-2 mt-2 text-sm text-slate-500">
                        <Calendar className="w-4 h-4" />
                        <span>{news.date}</span>
                      </div>
                    </div>
                  </div>
                  <span className={`text-xs px-3 py-1 rounded-full ${
                    news.impact === 'Crítico'
                      ? 'bg-red-100 text-red-700'
                      : news.impact === 'Alto'
                      ? 'bg-orange-100 text-orange-700'
                      : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    Impacto: {news.impact}
                  </span>
                </div>

                <h3 className="text-xl text-slate-900 mb-3 hover:text-blue-600 transition-colors cursor-pointer">
                  {news.title}
                </h3>

                <p className="text-slate-700 leading-relaxed mb-4">
                  {news.content}
                </p>

                <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg mb-4">
                  <p className="text-sm text-blue-900">
                    <strong>Lição aprendida:</strong> {news.lesson}
                  </p>
                </div>

                <button className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-2 group">
                  Ler mais
                  <ExternalLink className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </article>
          ))}
        </div>

        {/* Estatísticas */}
        <div className="mt-12 bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl p-8 text-white">
          <h3 className="text-2xl mb-6">Estatísticas de Ataques no Brasil (2026)</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <div className="text-4xl mb-2">88 bi</div>
              <div className="text-slate-300">Tentativas de ataques registradas</div>
            </div>
            <div>
              <div className="text-4xl mb-2">R$ 12 bi</div>
              <div className="text-slate-300">Prejuízo estimado para empresas</div>
            </div>
            <div>
              <div className="text-4xl mb-2">3,2 mi</div>
              <div className="text-slate-300">Brasileiros vítimas de golpes online</div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
