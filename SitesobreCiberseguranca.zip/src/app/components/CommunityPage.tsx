import {
  Shield, Bell, MessageCircle, ThumbsUp, Send, LogOut, Home, Settings,
  Search, AlertTriangle, CheckCircle, Share2, Bookmark, Flag, Sparkles,
  ChevronDown, ChevronUp, TrendingUp, Users, Trophy, Calendar, X,
  Reply, BarChart2, Star, Zap, Hash, Award
} from 'lucide-react';
import { Link } from 'react-router';
import { useState, useRef, useEffect } from 'react';
import logoImg from '../../imports/Logo_Olho_Digital.png';

interface CommunityPageProps {
  user: { name: string; email: string };
  onLogout: () => void;
}

interface Comment {
  id: number;
  author: string;
  avatar: string;
  time: string;
  content: string;
  replies: Comment[];
}

interface Post {
  id: number;
  author: string;
  avatar: string;
  time: string;
  content: string;
  type: string;
  likes: number;
  comments: number;
  saved?: boolean;
}

const initialPosts: Post[] = [
  {
    id: 1,
    author: 'Maria Silva',
    avatar: 'M',
    time: 'Há 2 horas',
    content: 'Pessoal, quase caí em um golpe hoje! Recebi um email que parecia ser do meu banco pedindo para "confirmar meus dados" urgentemente. Por sorte, lembrei das aulas aqui do Olho Digital e percebi que o domínio do email estava errado. Sempre verifiquem o remetente!',
    type: 'alerta',
    likes: 24,
    comments: 8,
  },
  {
    id: 2,
    author: 'João Pedro',
    avatar: 'J',
    time: 'Há 5 horas',
    content: 'Minha conta do Instagram foi hackeada semana passada. Consegui recuperar ativando a autenticação de dois fatores. Agora uso em todas as minhas contas. Recomendo muito!',
    type: 'experiencia',
    likes: 45,
    comments: 12,
  },
  {
    id: 3,
    author: 'Ana Costa',
    avatar: 'A',
    time: 'Há 8 horas',
    content: 'Atenção! Está circulando um link falso do WhatsApp que promete "modo escuro grátis". NÃO CLIQUEM! É malware. Vários amigos meus já caíram e tiveram dados roubados.',
    type: 'alerta',
    likes: 67,
    comments: 15,
  },
  {
    id: 4,
    author: 'Carlos Santos',
    avatar: 'C',
    time: 'Há 1 dia',
    content: 'Compartilhando minha experiência: recebi uma mensagem no celular dizendo que ganhei um prêmio e precisava clicar no link. Desconfiei porque nunca participei de sorteio nenhum. Pesquisei e era golpe mesmo. Cuidado!',
    type: 'experiencia',
    likes: 32,
    comments: 6,
  },
  {
    id: 5,
    author: 'Beatriz Lima',
    avatar: 'B',
    time: 'Há 1 dia',
    content: 'Dica importante: comecei a usar um gerenciador de senhas e minha vida mudou! Não preciso mais decorar senhas e cada conta tem uma senha única e forte. Vale muito a pena!',
    type: 'dica',
    likes: 89,
    comments: 20,
  },
  {
    id: 6,
    author: 'Rafael Oliveira',
    avatar: 'R',
    time: 'Há 2 dias',
    content: 'Cuidado com emails de "entrega de encomenda"! Recebi um dizendo que meu pacote estava retido e pedia para clicar em um link. Nunca fiz compra nenhuma. Não caiam nessa!',
    type: 'alerta',
    likes: 56,
    comments: 11,
  },
];

const aiAnalyses: Record<number, { risk: string; color: string; reasons: string[]; recommendation: string }> = {
  1: {
    risk: 'Alto',
    color: 'red',
    reasons: ['Link suspeito no email', 'Pedido de informações pessoais', 'Linguagem de urgência', 'Remetente não confiável'],
    recommendation: 'Nunca clique em links antes de verificar o domínio do remetente. Use o site oficial do banco diretamente.',
  },
  2: {
    risk: 'Médio',
    color: 'yellow',
    reasons: ['Conta comprometida sem 2FA', 'Senha potencialmente fraca', 'Acesso não autorizado detectado'],
    recommendation: 'Ative autenticação de dois fatores em todas as contas e use senhas únicas e fortes com gerenciador de senhas.',
  },
  3: {
    risk: 'Alto',
    color: 'red',
    reasons: ['Malware distribuído via link', 'Engenharia social aplicada', 'Phishing disfarçado de funcionalidade legítima', 'Roubo de dados confirmado'],
    recommendation: 'Nunca instale aplicativos ou clique em links de fontes não oficiais. Baixe apps apenas das lojas oficiais.',
  },
  4: {
    risk: 'Médio',
    color: 'yellow',
    reasons: ['Mensagem não solicitada', 'Promessa de prêmio falso', 'Link suspeito incluído'],
    recommendation: 'Desconfie sempre de mensagens com prêmios não solicitados. Golpes de "parabéns você ganhou" são muito comuns.',
  },
  5: {
    risk: 'Baixo',
    color: 'green',
    reasons: ['Prática de segurança recomendada', 'Uso de gerenciador de senhas', 'Senhas únicas por conta'],
    recommendation: 'Excelente prática! Complemente com autenticação de dois fatores e verifique periodicamente se seus dados foram vazados.',
  },
  6: {
    risk: 'Alto',
    color: 'red',
    reasons: ['Phishing de rastreamento de encomenda', 'Link malicioso incluído', 'Urgência fabricada', 'Remetente fraudulento'],
    recommendation: 'Rastreie encomendas apenas pelos sites oficiais das transportadoras. Jamais clique em links de SMS/email não solicitados.',
  },
};

const sampleComments: Record<number, Comment[]> = {
  1: [
    { id: 1, author: 'Pedro Alves', avatar: 'P', time: 'Há 1 hora', content: 'Ótimo alerta! Passei pela mesma situação mês passado.', replies: [] },
    { id: 2, author: 'Carla Mendes', avatar: 'C', time: 'Há 30 min', content: 'Isso é phishing clássico. Sempre verificar o domínio!', replies: [
      { id: 3, author: 'Maria Silva', avatar: 'M', time: 'Há 20 min', content: 'Exatamente! Aprendi aqui no Olho Digital.', replies: [] },
    ]},
  ],
  2: [
    { id: 1, author: 'Lucas Freitas', avatar: 'L', time: 'Há 3 horas', content: 'O 2FA salvou muita gente. Uso em tudo!', replies: [] },
  ],
  3: [
    { id: 1, author: 'Amanda Costa', avatar: 'A', time: 'Há 6 horas', content: 'Compartilhei com minha família! Muito importante.', replies: [] },
    { id: 2, author: 'Roberto Lima', avatar: 'R', time: 'Há 5 horas', content: 'Esse golpe chegou pra mim também. Não caí graças ao site!', replies: [] },
  ],
  4: [{ id: 1, author: 'Fernanda Silva', avatar: 'F', time: 'Há 20 horas', content: 'Bom que você desconfiou! Esses golpes são muito comuns.', replies: [] }],
  5: [{ id: 1, author: 'Gustavo Ramos', avatar: 'G', time: 'Há 18 horas', content: 'Qual gerenciador você usa? Recomendo o Bitwarden!', replies: [] }],
  6: [{ id: 1, author: 'Helena Souza', avatar: 'H', time: 'Há 1 dia', content: 'Esse golpe da encomenda está muito frequente ultimamente.', replies: [] }],
};

const topMembers = [
  { name: 'Beatriz Lima', level: 'Expert', score: 2840, avatar: 'B', color: 'from-purple-500 to-purple-700' },
  { name: 'João Pedro', level: 'Avançado', score: 2210, avatar: 'J', color: 'from-blue-500 to-blue-700' },
  { name: 'Ana Costa', level: 'Avançado', score: 1975, avatar: 'A', color: 'from-teal-500 to-teal-700' },
  { name: 'Carlos Santos', level: 'Intermediário', score: 1540, avatar: 'C', color: 'from-green-500 to-green-700' },
  { name: 'Rafael Oliveira', level: 'Intermediário', score: 1320, avatar: 'R', color: 'from-orange-500 to-orange-700' },
];

const upcomingEvents = [
  { name: 'CTF para Iniciantes', date: '10 Ago, 19h' },
  { name: 'Webinar: OWASP Top 10', date: '14 Ago, 20h' },
  { name: 'Workshop Phishing', date: '21 Ago, 18h' },
];

const trendingTopics = [
  '#Phishing', '#OWASP', '#Windows', '#Python',
  '#LGPD', '#HackTheBox', '#BlueTeam', '#RedTeam',
];

const achievements = [
  { icon: '🛡️', label: 'Guardião' },
  { icon: '🔍', label: 'Detetive' },
  { icon: '🏆', label: 'Campeão' },
  { icon: '💡', label: 'Mentor' },
  { icon: '⚡', label: 'Veloz' },
  { icon: '🎯', label: 'Preciso' },
];

const avatarColors: Record<string, string> = {
  M: 'from-pink-500 to-rose-600',
  J: 'from-blue-500 to-blue-700',
  A: 'from-teal-500 to-emerald-600',
  C: 'from-orange-500 to-amber-600',
  B: 'from-purple-500 to-purple-700',
  R: 'from-red-500 to-red-700',
};

const FILTERS = ['Todos', 'Mais recentes', 'Mais curtidos', 'Sem resposta', 'Alertas', 'Experiências', 'Dicas'];

function RippleButton({ className, onClick, children }: { className?: string; onClick?: () => void; children: React.ReactNode }) {
  const btnRef = useRef<HTMLButtonElement>(null);

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    const btn = btnRef.current;
    if (!btn) return;
    const ripple = document.createElement('span');
    const rect = btn.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    ripple.style.cssText = `
      position:absolute;width:${size}px;height:${size}px;
      border-radius:50%;background:rgba(255,255,255,0.4);
      top:${e.clientY - rect.top - size / 2}px;left:${e.clientX - rect.left - size / 2}px;
      animation:ripple 0.5s ease-out forwards;pointer-events:none;
    `;
    btn.style.position = 'relative';
    btn.style.overflow = 'hidden';
    btn.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
    onClick?.();
  };

  return (
    <button ref={btnRef} className={className} onClick={handleClick}>
      {children}
    </button>
  );
}

export function CommunityPage({ user, onLogout }: CommunityPageProps) {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [newPost, setNewPost] = useState('');
  const [newPostType, setNewPostType] = useState<string>('experiencia');
  const [activeFilter, setActiveFilter] = useState('Todos');
  const [posts, setPosts] = useState<Post[]>(initialPosts);
  const [likedPosts, setLikedPosts] = useState<Set<number>>(new Set());
  const [savedPosts, setSavedPosts] = useState<Set<number>>(new Set());
  const [openComments, setOpenComments] = useState<Set<number>>(new Set());
  const [openAI, setOpenAI] = useState<Set<number>>(new Set());
  const [commentTexts, setCommentTexts] = useState<Record<number, string>>({});
  const [comments, setComments] = useState<Record<number, Comment[]>>(sampleComments);
  const [replyingTo, setReplyingTo] = useState<{ postId: number; commentId: number } | null>(null);
  const [replyText, setReplyText] = useState('');
  const [likeAnimating, setLikeAnimating] = useState<number | null>(null);
  const [reportedPosts, setReportedPosts] = useState<Set<number>>(new Set());

  const getFilteredPosts = () => {
    let filtered = [...posts];

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(p =>
        p.content.toLowerCase().includes(q) ||
        p.author.toLowerCase().includes(q) ||
        p.type.toLowerCase().includes(q)
      );
    }

    switch (activeFilter) {
      case 'Mais recentes': return filtered;
      case 'Mais curtidos': return [...filtered].sort((a, b) => b.likes - a.likes);
      case 'Sem resposta': return filtered.filter(p => p.comments === 0);
      case 'Alertas': return filtered.filter(p => p.type === 'alerta');
      case 'Experiências': return filtered.filter(p => p.type === 'experiencia');
      case 'Dicas': return filtered.filter(p => p.type === 'dica');
      default: return filtered;
    }
  };

  const handleLike = (postId: number) => {
    setLikeAnimating(postId);
    setTimeout(() => setLikeAnimating(null), 600);

    setLikedPosts(prev => {
      const next = new Set(prev);
      if (next.has(postId)) {
        next.delete(postId);
        setPosts(ps => ps.map(p => p.id === postId ? { ...p, likes: p.likes - 1 } : p));
      } else {
        next.add(postId);
        setPosts(ps => ps.map(p => p.id === postId ? { ...p, likes: p.likes + 1 } : p));
      }
      return next;
    });
  };

  const handleSave = (postId: number) => {
    setSavedPosts(prev => {
      const next = new Set(prev);
      next.has(postId) ? next.delete(postId) : next.add(postId);
      return next;
    });
  };

  const handleReport = (postId: number) => {
    setReportedPosts(prev => new Set([...prev, postId]));
  };

  const toggleComments = (postId: number) => {
    setOpenComments(prev => {
      const next = new Set(prev);
      next.has(postId) ? next.delete(postId) : next.add(postId);
      return next;
    });
  };

  const toggleAI = (postId: number) => {
    setOpenAI(prev => {
      const next = new Set(prev);
      next.has(postId) ? next.delete(postId) : next.add(postId);
      return next;
    });
  };

  const handleAddComment = (postId: number) => {
    const text = commentTexts[postId]?.trim();
    if (!text) return;
    const newComment: Comment = {
      id: Date.now(),
      author: user.name,
      avatar: user.name.charAt(0).toUpperCase(),
      time: 'Agora',
      content: text,
      replies: [],
    };
    setComments(prev => ({ ...prev, [postId]: [newComment, ...(prev[postId] || [])] }));
    setCommentTexts(prev => ({ ...prev, [postId]: '' }));
    setPosts(ps => ps.map(p => p.id === postId ? { ...p, comments: p.comments + 1 } : p));
  };

  const handleAddReply = (postId: number, commentId: number) => {
    if (!replyText.trim()) return;
    const reply: Comment = {
      id: Date.now(),
      author: user.name,
      avatar: user.name.charAt(0).toUpperCase(),
      time: 'Agora',
      content: replyText.trim(),
      replies: [],
    };
    setComments(prev => ({
      ...prev,
      [postId]: (prev[postId] || []).map(c =>
        c.id === commentId ? { ...c, replies: [...c.replies, reply] } : c
      ),
    }));
    setReplyText('');
    setReplyingTo(null);
  };

  const handlePublishPost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPost.trim()) return;
    const post: Post = {
      id: Date.now(),
      author: user.name,
      avatar: user.name.charAt(0).toUpperCase(),
      time: 'Agora',
      content: newPost.trim(),
      type: newPostType,
      likes: 0,
      comments: 0,
    };
    setPosts(prev => [post, ...prev]);
    setNewPost('');
  };

  const filteredPosts = getFilteredPosts();

  return (
    <>
      <style>{`
        @keyframes ripple { to { transform: scale(4); opacity: 0; } }
        @keyframes likePopIn { 0%{transform:scale(1)} 40%{transform:scale(1.4)} 70%{transform:scale(0.9)} 100%{transform:scale(1)} }
        @keyframes fadeSlideDown { from{opacity:0;transform:translateY(-8px)} to{opacity:1;transform:translateY(0)} }
        @keyframes fadeSlideUp { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        .like-pop { animation: likePopIn 0.5s ease; }
        .fade-slide-down { animation: fadeSlideDown 0.25s ease; }
        .fade-slide-up { animation: fadeSlideUp 0.3s ease; }
        .post-card { transition: box-shadow 0.25s ease, transform 0.25s ease; }
        .post-card:hover { box-shadow: 0 8px 32px rgba(37,99,235,0.12); transform: translateY(-2px); }
        .action-btn { transition: color 0.18s, background 0.18s, transform 0.18s; }
        .action-btn:hover { transform: scale(1.08); }
        .sidebar-card { transition: box-shadow 0.2s ease; }
        .sidebar-card:hover { box-shadow: 0 4px 16px rgba(37,99,235,0.09); }
        .topic-tag { transition: background 0.18s, color 0.18s, transform 0.18s; }
        .topic-tag:hover { transform: scale(1.05); }
        .filter-btn { transition: background 0.18s, color 0.18s, border-color 0.18s; }
      `}</style>

      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between py-4">
              <div className="flex items-center gap-8">
                <Link to="/home" className="flex items-center gap-3">
                  <img src={logoImg} alt="Olho Digital" className="h-10 w-auto mix-blend-multiply" />
                  <h1 className="text-xl text-blue-900">Olho Digital</h1>
                </Link>
                <nav className="hidden md:flex items-center gap-6">
                  <Link to="/home" className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors">
                    <Home className="w-4 h-4" /><span>Início</span>
                  </Link>
                  <Link to="/aprender" className="text-slate-600 hover:text-blue-600 transition-colors">Aprender</Link>
                  <Link to="/noticias" className="text-slate-600 hover:text-blue-600 transition-colors">Notícias</Link>
                  <Link to="/comunidade" className="text-blue-600 font-medium border-b-2 border-blue-600 pb-1">Comunidade</Link>
                </nav>
              </div>
              <div className="flex items-center gap-4">
                <div className="relative hidden md:block">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="Buscar discussões..."
                    className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-64 transition-all"
                  />
                </div>
                <button className="relative p-2 text-slate-600 hover:text-blue-600 transition-colors">
                  <Bell className="w-5 h-5" />
                  <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                </button>
                <div className="relative">
                  <button
                    onClick={() => setShowProfileMenu(!showProfileMenu)}
                    className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-100 transition-colors"
                  >
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center text-white font-medium">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                  </button>
                  {showProfileMenu && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-slate-200 py-2 z-10 fade-slide-down">
                      <button className="w-full px-4 py-2 text-left text-slate-700 hover:bg-slate-100 flex items-center gap-2">
                        <Settings className="w-4 h-4" /><span>Configurações</span>
                      </button>
                      <button onClick={onLogout} className="w-full px-4 py-2 text-left text-red-600 hover:bg-red-50 flex items-center gap-2">
                        <LogOut className="w-4 h-4" /><span>Sair</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Main Layout */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex gap-6 items-start">
            {/* Feed Column */}
            <div className="flex-1 min-w-0">
              <div className="mb-6">
                <h2 className="text-3xl text-slate-900 mb-1">Comunidade</h2>
                <p className="text-slate-500">Compartilhe experiências e ajude outros usuários</p>
              </div>

              {/* Nova Publicação */}
              <div className="bg-white rounded-xl border border-slate-200 p-5 mb-5 shadow-sm">
                <form onSubmit={handlePublishPost}>
                  <div className="flex gap-3 mb-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center text-white font-medium flex-shrink-0">
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <textarea
                      value={newPost}
                      onChange={e => setNewPost(e.target.value)}
                      placeholder="Compartilhe sua experiência, alerta ou dica sobre segurança digital..."
                      className="flex-1 border border-slate-200 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none text-sm transition-all"
                      rows={3}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex gap-2">
                      {[
                        { key: 'alerta', label: '⚠️ Alerta', active: 'bg-red-600 text-white', inactive: 'bg-red-100 text-red-700 hover:bg-red-200' },
                        { key: 'experiencia', label: '💬 Experiência', active: 'bg-blue-600 text-white', inactive: 'bg-blue-100 text-blue-700 hover:bg-blue-200' },
                        { key: 'dica', label: '💡 Dica', active: 'bg-green-600 text-white', inactive: 'bg-green-100 text-green-700 hover:bg-green-200' },
                      ].map(t => (
                        <button
                          key={t.key}
                          type="button"
                          onClick={() => setNewPostType(t.key)}
                          className={`text-xs px-3 py-1.5 rounded-full transition-all ${newPostType === t.key ? t.active : t.inactive}`}
                        >
                          {t.label}
                        </button>
                      ))}
                    </div>
                    <button
                      type="submit"
                      className="bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2 text-sm font-medium relative overflow-hidden"
                    >
                      <Send className="w-4 h-4" />Publicar
                    </button>
                  </div>
                </form>
              </div>

              {/* Filtros */}
              <div className="flex gap-2 flex-wrap mb-4">
                {FILTERS.map(f => (
                  <button
                    key={f}
                    onClick={() => setActiveFilter(f)}
                    className={`filter-btn text-xs px-3 py-1.5 rounded-full border transition-all font-medium ${
                      activeFilter === f
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-slate-600 border-slate-200 hover:border-blue-400 hover:text-blue-600'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>

              {/* Posts */}
              <div className="space-y-4">
                {filteredPosts.length === 0 && (
                  <div className="bg-white rounded-xl border border-slate-200 p-10 text-center text-slate-500">
                    Nenhuma publicação encontrada.
                  </div>
                )}
                {filteredPosts.map(post => {
                  const isLiked = likedPosts.has(post.id);
                  const isSaved = savedPosts.has(post.id);
                  const isCommentsOpen = openComments.has(post.id);
                  const isAIOpen = openAI.has(post.id);
                  const isAnimatingLike = likeAnimating === post.id;
                  const isReported = reportedPosts.has(post.id);
                  const ai = aiAnalyses[post.id];
                  const postComments = comments[post.id] || [];

                  return (
                    <div key={post.id} className="post-card bg-white rounded-xl border border-slate-200 overflow-hidden">
                      <div className="p-5">
                        <div className="flex items-start gap-3">
                          <div className={`w-11 h-11 bg-gradient-to-br ${avatarColors[post.avatar] || 'from-blue-500 to-blue-700'} rounded-full flex items-center justify-center text-white font-medium flex-shrink-0`}>
                            {post.avatar}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-1">
                              <div>
                                <span className="font-medium text-slate-900 text-sm">{post.author}</span>
                                <span className="text-slate-400 text-xs ml-2">{post.time}</span>
                              </div>
                              <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                                post.type === 'alerta' ? 'bg-red-100 text-red-700' :
                                post.type === 'experiencia' ? 'bg-blue-100 text-blue-700' :
                                'bg-green-100 text-green-700'
                              }`}>
                                {post.type === 'alerta' ? '⚠️ Alerta' :
                                 post.type === 'experiencia' ? '💬 Experiência' : '💡 Dica'}
                              </span>
                            </div>
                            <p className="text-slate-700 text-sm leading-relaxed">{post.content}</p>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-1 mt-4 pt-3 border-t border-slate-100 flex-wrap">
                          {/* Curtir */}
                          <button
                            onClick={() => handleLike(post.id)}
                            className={`action-btn flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${
                              isLiked ? 'text-blue-600 bg-blue-50' : 'text-slate-500 hover:text-blue-600 hover:bg-blue-50'
                            }`}
                          >
                            <ThumbsUp className={`w-4 h-4 ${isAnimatingLike ? 'like-pop' : ''}`} />
                            <span>{post.likes}</span>
                          </button>

                          {/* Comentar */}
                          <button
                            onClick={() => toggleComments(post.id)}
                            className={`action-btn flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${
                              isCommentsOpen ? 'text-blue-600 bg-blue-50' : 'text-slate-500 hover:text-blue-600 hover:bg-blue-50'
                            }`}
                          >
                            <MessageCircle className="w-4 h-4" />
                            <span>{post.comments}</span>
                          </button>

                          {/* Compartilhar */}
                          <button className="action-btn flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium text-slate-500 hover:text-emerald-600 hover:bg-emerald-50">
                            <Share2 className="w-4 h-4" />
                            <span className="hidden sm:inline">Compartilhar</span>
                          </button>

                          {/* Salvar */}
                          <button
                            onClick={() => handleSave(post.id)}
                            className={`action-btn flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${
                              isSaved ? 'text-amber-600 bg-amber-50' : 'text-slate-500 hover:text-amber-600 hover:bg-amber-50'
                            }`}
                          >
                            <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                            <span className="hidden sm:inline">Salvar</span>
                          </button>

                          {/* Denunciar */}
                          <button
                            onClick={() => handleReport(post.id)}
                            disabled={isReported}
                            className={`action-btn flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${
                              isReported ? 'text-slate-300 cursor-not-allowed' : 'text-slate-500 hover:text-red-500 hover:bg-red-50'
                            }`}
                          >
                            <Flag className="w-4 h-4" />
                            <span className="hidden sm:inline">{isReported ? 'Denunciado' : 'Denunciar'}</span>
                          </button>

                          {/* Análise IA */}
                          {ai && (
                            <button
                              onClick={() => toggleAI(post.id)}
                              className={`action-btn ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium ${
                                isAIOpen ? 'text-violet-600 bg-violet-50' : 'text-slate-500 hover:text-violet-600 hover:bg-violet-50'
                              }`}
                            >
                              <Sparkles className="w-4 h-4" />
                              <span className="hidden sm:inline">Análise da IA</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {/* AI Analysis Panel */}
                      {isAIOpen && ai && (
                        <div className="fade-slide-down border-t border-violet-100 bg-gradient-to-br from-violet-50 to-indigo-50 px-5 py-4">
                          <div className="flex items-center gap-2 mb-3">
                            <Sparkles className="w-4 h-4 text-violet-600" />
                            <span className="text-sm font-semibold text-violet-800">Análise Automática de Segurança</span>
                          </div>
                          <div className="flex items-center gap-2 mb-3">
                            <span className="text-xs font-medium text-slate-600">Risco identificado:</span>
                            <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                              ai.color === 'red' ? 'bg-red-100 text-red-700' :
                              ai.color === 'yellow' ? 'bg-yellow-100 text-yellow-700' :
                              'bg-green-100 text-green-700'
                            }`}>
                              {ai.color === 'red' ? '🔴' : ai.color === 'yellow' ? '🟡' : '🟢'} {ai.risk}
                            </span>
                          </div>
                          <div className="mb-3">
                            <p className="text-xs font-semibold text-slate-600 mb-1.5">Motivos:</p>
                            <ul className="space-y-1">
                              {ai.reasons.map((r, i) => (
                                <li key={i} className="flex items-start gap-1.5 text-xs text-slate-700">
                                  <span className="text-violet-500 mt-0.5">•</span>{r}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div className="bg-white/70 rounded-lg p-3 border border-violet-100">
                            <p className="text-xs font-semibold text-slate-600 mb-1">Recomendação:</p>
                            <p className="text-xs text-slate-700 leading-relaxed">{ai.recommendation}</p>
                          </div>
                        </div>
                      )}

                      {/* Comments Panel */}
                      {isCommentsOpen && (
                        <div className="fade-slide-down border-t border-slate-100 bg-slate-50 px-5 py-4">
                          {/* Add Comment */}
                          <div className="flex gap-2 mb-4">
                            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center text-white text-xs font-medium flex-shrink-0">
                              {user.name.charAt(0).toUpperCase()}
                            </div>
                            <div className="flex-1 flex gap-2">
                              <input
                                type="text"
                                value={commentTexts[post.id] || ''}
                                onChange={e => setCommentTexts(prev => ({ ...prev, [post.id]: e.target.value }))}
                                onKeyDown={e => e.key === 'Enter' && handleAddComment(post.id)}
                                placeholder="Escreva um comentário..."
                                className="flex-1 border border-slate-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                              />
                              <button
                                onClick={() => handleAddComment(post.id)}
                                className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                              >
                                <Send className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          {/* Comments List */}
                          <div className="space-y-3">
                            {postComments.length === 0 && (
                              <p className="text-xs text-slate-400 text-center py-2">Seja o primeiro a comentar!</p>
                            )}
                            {postComments.map(comment => (
                              <div key={comment.id} className="fade-slide-up">
                                <div className="flex gap-2">
                                  <div className="w-8 h-8 bg-gradient-to-br from-slate-400 to-slate-600 rounded-full flex items-center justify-center text-white text-xs font-medium flex-shrink-0">
                                    {comment.avatar}
                                  </div>
                                  <div className="flex-1">
                                    <div className="bg-white rounded-xl px-3 py-2 border border-slate-100">
                                      <div className="flex items-center gap-2 mb-1">
                                        <span className="text-xs font-semibold text-slate-800">{comment.author}</span>
                                        <span className="text-xs text-slate-400">{comment.time}</span>
                                      </div>
                                      <p className="text-sm text-slate-700">{comment.content}</p>
                                    </div>
                                    <button
                                      onClick={() => setReplyingTo(
                                        replyingTo?.commentId === comment.id ? null : { postId: post.id, commentId: comment.id }
                                      )}
                                      className="flex items-center gap-1 text-xs text-slate-400 hover:text-blue-500 mt-1 ml-1 transition-colors"
                                    >
                                      <Reply className="w-3 h-3" />Responder
                                    </button>

                                    {/* Reply Input */}
                                    {replyingTo?.commentId === comment.id && replyingTo.postId === post.id && (
                                      <div className="flex gap-2 mt-2 fade-slide-down">
                                        <input
                                          type="text"
                                          value={replyText}
                                          onChange={e => setReplyText(e.target.value)}
                                          onKeyDown={e => e.key === 'Enter' && handleAddReply(post.id, comment.id)}
                                          placeholder={`Responder ${comment.author}...`}
                                          autoFocus
                                          className="flex-1 border border-blue-300 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                                        />
                                        <button onClick={() => handleAddReply(post.id, comment.id)} className="p-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                          <Send className="w-3 h-3" />
                                        </button>
                                        <button onClick={() => setReplyingTo(null)} className="p-1.5 text-slate-400 hover:text-slate-600">
                                          <X className="w-3 h-3" />
                                        </button>
                                      </div>
                                    )}

                                    {/* Nested Replies */}
                                    {comment.replies.length > 0 && (
                                      <div className="mt-2 ml-4 space-y-2">
                                        {comment.replies.map(reply => (
                                          <div key={reply.id} className="flex gap-2 fade-slide-up">
                                            <div className="w-7 h-7 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white text-xs font-medium flex-shrink-0">
                                              {reply.avatar}
                                            </div>
                                            <div className="bg-white rounded-xl px-3 py-2 border border-slate-100 flex-1">
                                              <div className="flex items-center gap-2 mb-0.5">
                                                <span className="text-xs font-semibold text-slate-800">{reply.author}</span>
                                                <span className="text-xs text-slate-400">{reply.time}</span>
                                              </div>
                                              <p className="text-sm text-slate-700">{reply.content}</p>
                                            </div>
                                          </div>
                                        ))}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right Sidebar */}
            <aside className="hidden lg:flex flex-col gap-4 w-72 flex-shrink-0">
              {/* Community Stats */}
              <div className="sidebar-card bg-white rounded-xl border border-slate-200 p-4">
                <div className="flex items-center gap-2 mb-3">
                  <BarChart2 className="w-4 h-4 text-blue-600" />
                  <h3 className="text-sm font-semibold text-slate-800">Estatísticas</h3>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: 'Membros', value: '12.4k', icon: '👥' },
                    { label: 'Publicações', value: '3.8k', icon: '📝' },
                    { label: 'Comentários', value: '18.2k', icon: '💬' },
                    { label: 'Eventos', value: '47', icon: '🎯' },
                  ].map(stat => (
                    <div key={stat.label} className="bg-blue-50 rounded-lg p-2.5 text-center">
                      <div className="text-lg mb-0.5">{stat.icon}</div>
                      <div className="text-base font-bold text-blue-700">{stat.value}</div>
                      <div className="text-xs text-slate-500">{stat.label}</div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex items-center gap-2 px-3 py-2 bg-green-50 rounded-lg">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                  <span className="text-xs text-green-700 font-medium">284 online agora</span>
                </div>
              </div>

              {/* Top Members */}
              <div className="sidebar-card bg-white rounded-xl border border-slate-200 p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Trophy className="w-4 h-4 text-amber-500" />
                  <h3 className="text-sm font-semibold text-slate-800">Ranking da Semana</h3>
                </div>
                <div className="space-y-2">
                  {topMembers.map((member, i) => (
                    <div key={member.name} className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-slate-50 transition-colors cursor-default">
                      <span className={`text-xs font-bold w-5 text-center ${i === 0 ? 'text-amber-500' : i === 1 ? 'text-slate-400' : i === 2 ? 'text-amber-700' : 'text-slate-400'}`}>
                        {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}º`}
                      </span>
                      <div className={`w-8 h-8 bg-gradient-to-br ${member.color} rounded-full flex items-center justify-center text-white text-xs font-medium flex-shrink-0`}>
                        {member.avatar}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-slate-800 truncate">{member.name}</p>
                        <p className="text-xs text-slate-400">{member.level}</p>
                      </div>
                      <span className="text-xs font-semibold text-blue-600">{member.score.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Upcoming Events */}
              <div className="sidebar-card bg-white rounded-xl border border-slate-200 p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <h3 className="text-sm font-semibold text-slate-800">Próximos Eventos</h3>
                </div>
                <div className="space-y-2">
                  {upcomingEvents.map(ev => (
                    <div key={ev.name} className="flex items-center justify-between p-2.5 bg-blue-50 rounded-lg">
                      <div>
                        <p className="text-xs font-medium text-slate-800">{ev.name}</p>
                        <p className="text-xs text-slate-500">{ev.date}</p>
                      </div>
                      <button className="text-xs bg-blue-600 text-white px-2.5 py-1 rounded-md hover:bg-blue-700 transition-colors font-medium whitespace-nowrap">
                        Participar
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Trending Topics */}
              <div className="sidebar-card bg-white rounded-xl border border-slate-200 p-4">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp className="w-4 h-4 text-blue-600" />
                  <h3 className="text-sm font-semibold text-slate-800">Tópicos em Alta</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {trendingTopics.map(tag => (
                    <button
                      key={tag}
                      className="topic-tag text-xs px-2.5 py-1 bg-slate-100 hover:bg-blue-100 text-slate-600 hover:text-blue-700 rounded-full font-medium"
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>

              {/* Weekly Challenge */}
              <div className="sidebar-card bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl p-4 text-white">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-yellow-300" />
                  <h3 className="text-sm font-semibold">Desafio da Semana</h3>
                </div>
                <p className="text-xs text-blue-100 mb-1 font-medium">CTF: Análise de Phishing</p>
                <p className="text-xs text-blue-200 leading-relaxed mb-3">
                  Identifique os 5 indicadores de phishing no email fornecido e documente cada um. Ganhe 500 XP!
                </p>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs text-blue-200">⏱ Termina em 3 dias</span>
                  <span className="text-xs bg-yellow-400 text-yellow-900 px-2 py-0.5 rounded-full font-bold">500 XP</span>
                </div>
                <button className="w-full bg-white text-blue-700 text-xs font-bold py-2 rounded-lg hover:bg-blue-50 transition-colors">
                  Participar do Desafio
                </button>
              </div>

              {/* Achievements */}
              <div className="sidebar-card bg-white rounded-xl border border-slate-200 p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Award className="w-4 h-4 text-amber-500" />
                  <h3 className="text-sm font-semibold text-slate-800">Conquistas</h3>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {achievements.map(a => (
                    <div
                      key={a.label}
                      className="flex flex-col items-center gap-1 p-2 bg-amber-50 rounded-lg hover:bg-amber-100 transition-colors cursor-default group"
                    >
                      <span className="text-xl group-hover:scale-110 transition-transform inline-block">{a.icon}</span>
                      <span className="text-xs text-slate-600 font-medium">{a.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </aside>
          </div>
        </main>
      </div>
    </>
  );
}
