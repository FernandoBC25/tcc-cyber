import { LucideIcon } from 'lucide-react';

interface Attack {
  id: string;
  icon: LucideIcon;
  title: string;
  description: string;
  details: string;
  color: string;
}

interface AttackCardProps {
  attack: Attack;
  isSelected: boolean;
  onSelect: () => void;
}

const colorClasses: Record<string, { bg: string; text: string; border: string; hover: string }> = {
  blue: {
    bg: 'bg-blue-50',
    text: 'text-blue-600',
    border: 'border-blue-200',
    hover: 'hover:border-blue-400'
  },
  red: {
    bg: 'bg-red-50',
    text: 'text-red-600',
    border: 'border-red-200',
    hover: 'hover:border-red-400'
  },
  purple: {
    bg: 'bg-purple-50',
    text: 'text-purple-600',
    border: 'border-purple-200',
    hover: 'hover:border-purple-400'
  },
  orange: {
    bg: 'bg-orange-50',
    text: 'text-orange-600',
    border: 'border-orange-200',
    hover: 'hover:border-orange-400'
  },
  green: {
    bg: 'bg-green-50',
    text: 'text-green-600',
    border: 'border-green-200',
    hover: 'hover:border-green-400'
  },
  pink: {
    bg: 'bg-pink-50',
    text: 'text-pink-600',
    border: 'border-pink-200',
    hover: 'hover:border-pink-400'
  }
};

export function AttackCard({ attack, isSelected, onSelect }: AttackCardProps) {
  const Icon = attack.icon;
  const colors = colorClasses[attack.color] || colorClasses.blue;

  return (
    <div
      onClick={onSelect}
      className={`bg-white rounded-xl p-6 border-2 cursor-pointer transition-all duration-300 ${
        isSelected ? `${colors.border} shadow-lg scale-105` : `border-slate-200 ${colors.hover} hover:shadow-md`
      }`}
    >
      <div className={`${colors.bg} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
        <Icon className={`w-6 h-6 ${colors.text}`} />
      </div>
      <h3 className="text-slate-900 mb-2">{attack.title}</h3>
      <p className="text-slate-600 text-sm leading-relaxed mb-3">
        {attack.description}
      </p>
      {isSelected && (
        <div className={`${colors.bg} p-4 rounded-lg mt-4 border ${colors.border}`}>
          <p className={`text-sm ${colors.text} leading-relaxed`}>
            {attack.details}
          </p>
        </div>
      )}
      <button
        className={`text-sm mt-3 ${colors.text} hover:underline`}
      >
        {isSelected ? 'Ver menos' : 'Saiba mais'}
      </button>
    </div>
  );
}
