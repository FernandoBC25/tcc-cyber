import { LucideIcon } from 'lucide-react';

interface Stat {
  value: string;
  label: string;
  icon: LucideIcon;
  trend: string;
}

interface StatCardProps {
  stat: Stat;
}

export function StatCard({ stat }: StatCardProps) {
  const Icon = stat.icon;

  return (
    <div className="bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl p-8 text-white relative overflow-hidden group hover:scale-105 transition-transform duration-300">
      <div className="absolute top-0 right-0 opacity-10 transform translate-x-4 -translate-y-4">
        <Icon className="w-32 h-32" />
      </div>
      <div className="relative">
        <div className="flex items-center gap-2 mb-4">
          <Icon className="w-6 h-6" />
          <span className="bg-white/20 px-2 py-1 rounded text-xs">{stat.trend}</span>
        </div>
        <div className="text-4xl mb-2">{stat.value}</div>
        <div className="text-blue-100">{stat.label}</div>
      </div>
    </div>
  );
}
