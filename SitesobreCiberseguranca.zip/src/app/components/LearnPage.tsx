import { Shield, Bell, BookOpen, Video, FlaskConical, Library, ChevronRight, Clock, Users, LogOut, Home, Settings, Search, Star, Play, Award } from 'lucide-react';
import { Link } from 'react-router';
import { useState } from 'react';
import logoImg from '../../imports/Logo_Olho_Digital.png';

interface LearnPageProps {
  user: { name: string; email: string };
  onLogout: () => void;
}

export function LearnPage({ user, onLogout }: LearnPageProps) {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const courses = [
    {
      title: 'Fundamentos de Cibersegurança',
      level: 'Iniciante',
      duration: '8 horas',
      lessons: 24,
      students: 1250,
      rating: 4.8,
      progress: 0
    },
    {
      title: 'Proteção Contra Phishing',
      level: 'Iniciante',
      duration: '4 horas',
      lessons: 12,
      students: 980,
      rating: 4.9,
      progress: 0
    },
    {
      title: 'Segurança de Redes',
      level: 'Intermediário',
      duration: '12 horas',
      lessons: 32,
      students: 750,
      rating: 4.7,
      progress: 0
    },
    {
      title: 'Análise de Malware',
      level: 'Avançado',
      duration: '16 horas',
      lessons: 40,
      students: 420,
      rating: 4.9,
      progress: 0
    }
  ];

  const videos = [
    {
      title: 'Como criar senhas seguras',
      duration: '12:34',
      views: '15.2k',
      thumbnail: 'video1'
    },
    {
      title: 'Identificando emails de phishing',
      duration: '18:45',
      views: '23.1k',
      thumbnail: 'video2'
    },
    {
      title: 'Configurando autenticação de dois fatores',
      duration: '10:22',
      views: '19.8k',
      thumbnail: 'video3'
    },
    {
      title: 'Navegação segura na internet',
      duration: '15:16',
      views: '12.5k',
      thumbnail: 'video4'
    }
  ];

  const labs = [
    {
      title: 'Simulação de Ataque de Phishing',
      difficulty: 'Fácil',
      description: 'Aprenda a identificar emails maliciosos em um ambiente seguro',
      completed: false
    },
    {
      title: 'Análise de Tráfego de Rede',
      difficulty: 'Médio',
      description: 'Use ferramentas para analisar e identificar atividades suspeitas',
      completed: false
    },
    {
      title: 'Pen Testing Básico',
      difficulty: 'Difícil',
      description: 'Pratique técnicas éticas de teste de penetração',
      completed: false
    }
  ];

  const library = [
    {
      title: 'Guia Completo de LGPD',
      type: 'PDF',
      pages: 45,
      downloads: '3.2k'
    },
    {
      title: 'Checklist de Segurança Pessoal',
      type: 'PDF',
      pages: 8,
      downloads: '8.5k'
    },
    {
      title: 'Manual de Resposta a Incidentes',
      type: 'PDF',
      pages: 32,
      downloads: '2.1k'
    },
    {
      title: 'Glossário de Cibersegurança',
      type: 'PDF',
      pages: 18,
      downloads: '5.7k'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center gap-8">
              <Link to="/home" className="flex items-center gap-3">
                <img src={logoImg} alt="Olho Digital" className="h-10 w-auto mix-blend-multiply" />
                <h1 className="text-xl text-blue-900">Olho Digital</h1>
              </Link>
              <nav className="hidden md:flex items-center gap-6">
                <Link to="/home" className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors">
                  <Home className="w-4 h-4" />
                  <span>Início</span>
                </Link>
                <Link to="/aprender" className="text-blue-600">Aprender</Link>
                <Link to="/noticias" className="text-slate-600 hover:text-blue-600 transition-colors">Notícias</Link>
                <Link to="/comunidade" className="text-slate-600 hover:text-blue-600 transition-colors">Comunidade</Link>
              </nav>
            </div>

            <div className="flex items-center gap-4">
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar conteúdo..."
                  className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-64"
                />
              </div>

              <button className="relative p-2 text-slate-600 hover:text-blue-600 transition-colors">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>

              <div className="relative">
                <button
                  onClick={() => setShowProfileMenu(!showProfileMenu)}
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center text-white">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                </button>

                {showProfileMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-slate-200 py-2 z-10">
                    <button className="w-full px-4 py-2 text-left text-slate-700 hover:bg-slate-100 flex items-center gap-2">
                      <Settings className="w-4 h-4" />
                      <span>Configurações</span>
                    </button>
                    <button
                      onClick={onLogout}
                      className="w-full px-4 py-2 text-left text-red-600 hover:bg-red-50 flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sair</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl text-slate-900 mb-2">Central de Aprendizado</h2>
          <p className="text-slate-600">Expanda seus conhecimentos em cibersegurança</p>
        </div>

        {/* Cursos */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-2 rounded-lg">
                <BookOpen className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-2xl text-slate-900">Cursos</h3>
            </div>
            <button className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1">
              Ver todos
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {courses.map((course, index) => (
              <div key={index} className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
                <div className="bg-gradient-to-br from-blue-500 to-blue-700 p-6 text-white">
                  <div className="text-xs bg-white/20 px-2 py-1 rounded inline-block mb-2">
                    {course.level}
                  </div>
                  <h4 className="mb-2 group-hover:scale-105 transition-transform">{course.title}</h4>
                </div>
                <div className="p-4 space-y-3">
                  <div className="flex items-center justify-between text-sm text-slate-600">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>{course.duration}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      <span>{course.rating}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm text-slate-600">
                    <span>{course.lessons} aulas</span>
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      <span>{course.students}</span>
                    </div>
                  </div>
                  <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors">
                    Começar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Vídeo Aulas */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="bg-purple-100 p-2 rounded-lg">
                <Video className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-2xl text-slate-900">Vídeo Aulas</h3>
            </div>
            <button className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1">
              Ver todos
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {videos.map((video, index) => (
              <div key={index} className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
                <div className="relative bg-gradient-to-br from-purple-400 to-purple-600 aspect-video flex items-center justify-center">
                  <Play className="w-12 h-12 text-white group-hover:scale-110 transition-transform" />
                  <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                    {video.duration}
                  </div>
                </div>
                <div className="p-4">
                  <h4 className="text-slate-900 mb-2">{video.title}</h4>
                  <p className="text-sm text-slate-600">{video.views} visualizações</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Laboratório */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="bg-green-100 p-2 rounded-lg">
                <FlaskConical className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-2xl text-slate-900">Laboratório Prático</h3>
            </div>
            <button className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1">
              Ver todos
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {labs.map((lab, index) => (
              <div key={index} className="bg-white rounded-xl border border-slate-200 p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <h4 className="text-slate-900">{lab.title}</h4>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    lab.difficulty === 'Fácil' ? 'bg-green-100 text-green-700' :
                    lab.difficulty === 'Médio' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {lab.difficulty}
                  </span>
                </div>
                <p className="text-slate-600 text-sm mb-4">{lab.description}</p>
                <button className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-colors">
                  Iniciar Lab
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* Biblioteca */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="bg-orange-100 p-2 rounded-lg">
                <Library className="w-6 h-6 text-orange-600" />
              </div>
              <h3 className="text-2xl text-slate-900">Biblioteca</h3>
            </div>
            <button className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1">
              Ver todos
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {library.map((item, index) => (
              <div key={index} className="bg-white rounded-xl border border-slate-200 p-6 hover:shadow-lg transition-shadow cursor-pointer group">
                <div className="bg-orange-100 p-3 rounded-lg inline-block mb-4">
                  <BookOpen className="w-6 h-6 text-orange-600" />
                </div>
                <h4 className="text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">{item.title}</h4>
                <div className="flex items-center justify-between text-sm text-slate-600 mb-4">
                  <span>{item.type} • {item.pages} páginas</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500">{item.downloads} downloads</span>
                  <button className="text-blue-600 hover:text-blue-700 text-sm">
                    Baixar
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
