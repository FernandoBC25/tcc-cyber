import { Shield, Lock, AlertTriangle, Eye, Bug, Fingerprint, Database, Wifi, ChevronRight, TrendingUp } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router';
import { AttackCard } from './AttackCard';
import { StatCard } from './StatCard';
import logoImg from '../../imports/Logo_Olho_Digital.png';

export function LandingPage() {
  const [selectedAttack, setSelectedAttack] = useState<string | null>(null);

  const attacks = [
    {
      id: 'phishing',
      icon: Bug,
      title: 'Phishing',
      description: 'Tentativas de enganar usuários para revelar informações confidenciais através de e-mails ou sites falsos.',
      details: 'O phishing é responsável por 90% das violações de dados. Ataques incluem e-mails fraudulentos, páginas falsas de login e mensagens de texto maliciosas.',
      color: 'blue'
    },
    {
      id: 'malware',
      icon: AlertTriangle,
      title: 'Malware',
      description: 'Software malicioso projetado para danificar, interromper ou obter acesso não autorizado a sistemas.',
      details: 'Inclui vírus, trojans, ransomware e spyware. Mais de 560.000 novos malwares são detectados diariamente.',
      color: 'red'
    },
    {
      id: 'ddos',
      icon: Wifi,
      title: 'DDoS',
      description: 'Ataques de negação de serviço distribuídos que sobrecarregam sistemas com tráfego excessivo.',
      details: 'Ataques DDoS podem derrubar sites e serviços por horas. Em 2025, houve aumento de 25% desses ataques.',
      color: 'purple'
    },
    {
      id: 'sql-injection',
      icon: Database,
      title: 'SQL Injection',
      description: 'Inserção de código SQL malicioso para manipular ou acessar bancos de dados.',
      details: 'Permite que atacantes acessem, modifiquem ou deletem dados sensíveis. Continua entre os top 10 riscos da OWASP.',
      color: 'orange'
    },
    {
      id: 'man-in-the-middle',
      icon: Eye,
      title: 'Man-in-the-Middle',
      description: 'Interceptação de comunicação entre duas partes para roubar ou modificar dados.',
      details: 'Comum em redes Wi-Fi públicas não seguras. Atacantes podem capturar senhas, dados bancários e mensagens.',
      color: 'green'
    },
    {
      id: 'ransomware',
      icon: Lock,
      title: 'Ransomware',
      description: 'Malware que criptografa dados e exige pagamento para restaurar o acesso.',
      details: 'Em 2025, o custo médio de um ataque de ransomware ultrapassou US$ 4,5 milhões. Ataques aumentaram 150% desde 2023.',
      color: 'pink'
    }
  ];

  const stats = [
    {
      value: '2.200',
      label: 'Ataques cibernéticos por dia',
      icon: TrendingUp,
      trend: '+15%'
    },
    {
      value: '95%',
      label: 'Causados por erro humano',
      icon: Fingerprint,
      trend: 'crítico'
    },
    {
      value: 'US$ 8 tri',
      label: 'Custo global estimado (2026)',
      icon: Shield,
      trend: '+23%'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header/Navigation */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-blue-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3">
              <img src={logoImg} alt="Olho Digital" className="h-10 w-auto" />
              <h1 className="text-xl text-blue-900">Olho Digital</h1>
            </Link>
            <nav className="flex items-center gap-6">
              <a href="#sobre" className="text-slate-600 hover:text-blue-600 transition-colors hidden md:block">Sobre</a>
              <a href="#ataques" className="text-slate-600 hover:text-blue-600 transition-colors hidden md:block">Tipos de Ataques</a>
              <a href="#dados" className="text-slate-600 hover:text-blue-600 transition-colors hidden md:block">Estatísticas</a>
              <Link
                to="/login"
                className="text-blue-600 hover:text-blue-700 transition-colors"
              >
                Login
              </Link>
              <Link
                to="/register"
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Cadastrar
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <div className="text-center max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-6xl text-slate-900 mb-6">
            Entenda a Importância da <span className="text-blue-600">Cibersegurança</span>
          </h2>
          <p className="text-lg md:text-xl text-slate-600 mb-8 leading-relaxed">
            Um portal educacional sobre segurança digital, tipos de ataques cibernéticos e como proteger suas informações no mundo conectado.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#sobre"
              className="inline-flex items-center justify-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Começar a Aprender
              <ChevronRight className="w-4 h-4" />
            </a>
            <a
              href="#ataques"
              className="inline-flex items-center justify-center gap-2 bg-white text-blue-600 px-6 py-3 rounded-lg border-2 border-blue-600 hover:bg-blue-50 transition-colors"
            >
              Ver Tipos de Ataques
            </a>
          </div>
        </div>
      </section>

      {/* O que é Cibersegurança */}
      <section id="sobre" className="bg-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl text-slate-900 mb-6">
                O que é Cibersegurança?
              </h2>
              <p className="text-lg text-slate-600 mb-4 leading-relaxed">
                Cibersegurança é a prática de proteger sistemas, redes e programas de ataques digitais. Esses ataques geralmente visam acessar, alterar ou destruir informações sensíveis, extorquir dinheiro de usuários ou interromper processos normais de negócios.
              </p>
              <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                Com o aumento da conectividade digital, a cibersegurança tornou-se essencial para empresas, governos e indivíduos. A proteção adequada envolve múltiplas camadas de segurança distribuídas pelos computadores, redes, programas e dados.
              </p>
              <div className="flex flex-col gap-3">
                <div className="flex items-start gap-3">
                  <div className="bg-blue-100 p-2 rounded-lg mt-1">
                    <Shield className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-slate-900 mb-1">Proteção de Dados</h3>
                    <p className="text-slate-600">Segurança de informações pessoais e corporativas</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="bg-blue-100 p-2 rounded-lg mt-1">
                    <Lock className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-slate-900 mb-1">Segurança de Rede</h3>
                    <p className="text-slate-600">Proteção contra acessos não autorizados</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="bg-blue-100 p-2 rounded-lg mt-1">
                    <Fingerprint className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-slate-900 mb-1">Autenticação</h3>
                    <p className="text-slate-600">Verificação de identidade e controle de acesso</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl p-8 text-white">
                <h3 className="text-2xl mb-4">Por que é Importante?</h3>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2">
                    <ChevronRight className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Proteção contra roubo de identidade e fraudes financeiras</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <ChevronRight className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Preservação da privacidade pessoal e empresarial</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <ChevronRight className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Continuidade dos negócios e serviços essenciais</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <ChevronRight className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Conformidade com leis e regulamentações (LGPD)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <ChevronRight className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span>Proteção da infraestrutura crítica nacional</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tipos de Ataques */}
      <section id="ataques" className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl text-slate-900 mb-4">
              Principais Tipos de Ataques Cibernéticos
            </h2>
            <p className="text-lg text-slate-600 max-w-3xl mx-auto">
              Conheça as ameaças mais comuns que afetam empresas e usuários no Brasil e no mundo. Clique em cada card para mais detalhes.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {attacks.map((attack) => (
              <AttackCard
                key={attack.id}
                attack={attack}
                isSelected={selectedAttack === attack.id}
                onSelect={() => setSelectedAttack(selectedAttack === attack.id ? null : attack.id)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Estatísticas */}
      <section id="dados" className="bg-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl text-slate-900 mb-4">
              Dados e Estatísticas Globais
            </h2>
            <p className="text-lg text-slate-600 max-w-3xl mx-auto">
              Números que demonstram a urgência da cibersegurança no cenário atual
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {stats.map((stat, index) => (
              <StatCard key={index} stat={stat} />
            ))}
          </div>
          <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-2xl p-8 md:p-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl text-slate-900 mb-4">
                  A Situação no Brasil
                </h3>
                <p className="text-slate-700 mb-4 leading-relaxed">
                  O Brasil é o segundo país mais atacado da América Latina, com mais de 88 bilhões de tentativas de ataques cibernéticos registradas em 2025.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  Setores como financeiro, saúde e governo são os mais visados. A implementação da LGPD (Lei Geral de Proteção de Dados) aumentou a conscientização, mas os desafios permanecem grandes.
                </p>
              </div>
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-600">Setor Financeiro</span>
                    <span className="text-blue-600">35%</span>
                  </div>
                  <div className="w-full bg-blue-100 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '35%' }}></div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-600">Governo</span>
                    <span className="text-blue-600">28%</span>
                  </div>
                  <div className="w-full bg-blue-100 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '28%' }}></div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-600">Varejo</span>
                    <span className="text-blue-600">22%</span>
                  </div>
                  <div className="w-full bg-blue-100 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '22%' }}></div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-600">Outros</span>
                    <span className="text-blue-600">15%</span>
                  </div>
                  <div className="w-full bg-blue-100 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '15%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <img src={logoImg} alt="Olho Digital" className="h-8 w-auto" />
                <span className="text-lg">Olho Digital</span>
              </div>
              <p className="text-slate-400">
                Portal educacional sobre cibersegurança para conscientização e proteção digital.
              </p>
            </div>
            <div>
              <h4 className="mb-4">Links Úteis</h4>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#sobre" className="hover:text-blue-400 transition-colors">Sobre Cibersegurança</a></li>
                <li><a href="#ataques" className="hover:text-blue-400 transition-colors">Tipos de Ataques</a></li>
                <li><a href="#dados" className="hover:text-blue-400 transition-colors">Estatísticas</a></li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4">Recursos</h4>
              <ul className="space-y-2 text-slate-400">
                <li><a href="https://www.gov.br/pt-br/servicos/denunciar-crime-cibernetico" target="_blank" rel="noopener noreferrer" className="hover:text-blue-400 transition-colors">Denunciar Crime Cibernético</a></li>
                <li><a href="https://www.gov.br/governodigital/pt-br/seguranca-e-protecao-de-dados" target="_blank" rel="noopener noreferrer" className="hover:text-blue-400 transition-colors">Governo Digital - Segurança</a></li>
                <li><a href="https://www.cert.br/" target="_blank" rel="noopener noreferrer" className="hover:text-blue-400 transition-colors">CERT.br</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
            <p>&copy; 2026 Olho Digital. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
