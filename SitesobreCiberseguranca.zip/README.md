
  # Site sobre Cibersegurança

  This is a code bundle for Site sobre Cibersegurança. The original project is available at https://www.figma.com/design/mXCpLhsC3mXMJHwNxlX4Kg/Site-sobre-Ciberseguran%C3%A7a.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  